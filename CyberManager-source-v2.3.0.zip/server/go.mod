module cybermanager

go 1.24
