package main

// Inventory (added in v2.2.0): printing paper, envelopes, passport-photo paper, sticker paper.
//
// How the stock is worked out (so nothing can drift out of step):
//   remaining = last stock count (or 0)  + stock added since  - usage recorded since  - sales usage since
// "sales usage" is calculated live from the sales records, so correcting or deleting a sale
// automatically corrects the stock as well:
//   - printing paper      : every B&W / colour page printed uses 1 sheet
//   - passport photo paper: prints sold / prints-per-sheet (default 1 print = 1 sheet)
// Envelopes and sticker paper are not tied to a sale, so staff record what is used.

import (
	"fmt"
	"math"
	"net/http"
	"regexp"
	"time"
)

type InvItem struct {
	ID       string  `json:"id"`
	Name     string  `json:"name"`
	PackName string  `json:"packName"` // ream, bunch, packet
	UnitName string  `json:"unitName"` // sheets, envelopes
	PackSize float64 `json:"packSize"` // units in one pack
	Reorder  float64 `json:"reorder"`  // warn when this many packs (or fewer) are left
	PerSheet float64 `json:"perSheet"` // passport photo: prints that fit on one sheet
	Since    string  `json:"since"`    // counting of sales usage starts after this moment
}

type Inventory struct {
	Items []InvItem `json:"items"`
	Moves []Rec     `json:"moves"` // type: in | out | count   (qty is always in single units)
}

func nowTS() string { return time.Now().Format("2006-01-02T15:04:05") }

func defaultItems() []InvItem {
	since := nowTS()[:16] + ":00"
	return []InvItem{
		{ID: "paper", Name: "Printing paper", PackName: "ream", UnitName: "sheets", PackSize: 500, Reorder: 2, PerSheet: 1, Since: since},
		{ID: "envelope", Name: "Envelopes", PackName: "bunch", UnitName: "envelopes", PackSize: 50, Reorder: 2, PerSheet: 1, Since: since},
		{ID: "passport", Name: "Passport photo paper", PackName: "packet", UnitName: "sheets", PackSize: 100, Reorder: 1, PerSheet: 1, Since: since},
		{ID: "sticker", Name: "Sticker paper", PackName: "packet", UnitName: "sheets", PackSize: 100, Reorder: 1, PerSheet: 1, Since: since},
	}
}

func newInventory() *Inventory { return &Inventory{Items: defaultItems(), Moves: []Rec{}} }

// fix makes sure all four items exist and have sensible values (never removes anything).
func (iv *Inventory) fix() {
	if iv.Moves == nil {
		iv.Moves = []Rec{}
	}
	have := map[string]bool{}
	for i := range iv.Items {
		it := &iv.Items[i]
		have[it.ID] = true
		if it.PackSize <= 0 {
			it.PackSize = 1
		}
		if it.PerSheet <= 0 {
			it.PerSheet = 1
		}
		if it.Reorder < 0 {
			it.Reorder = 0
		}
		if it.Since == "" {
			it.Since = nowTS()[:16] + ":00"
		}
	}
	for _, d := range defaultItems() {
		if !have[d.ID] {
			iv.Items = append(iv.Items, d)
		}
	}
}

func (iv *Inventory) item(id string) *InvItem {
	for i := range iv.Items {
		if iv.Items[i].ID == id {
			return &iv.Items[i]
		}
	}
	return nil
}

// usage from sales after `from`, in single units, optionally only from day `fromDay` onward
func salesUse(it *InvItem, from, fromDay string) (used float64, bw, col float64) {
	prints := 0.0
	for _, t := range db.Transactions {
		ts := toStr(t["ts"])
		if ts < from || (fromDay != "" && ts[:min(10, len(ts))] < fromDay) {
			continue
		}
		q := num(t["qty"])
		if math.IsNaN(q) || q < 0 {
			continue
		}
		switch toStr(t["service"]) {
		case "print":
			if it.ID == "paper" {
				if toStr(t["mode"]) == "color" {
					col += q
				} else {
					bw += q
				}
			}
		case "passport":
			if it.ID == "passport" {
				prints += q
			}
		}
	}
	switch it.ID {
	case "paper":
		used = bw + col
	case "passport":
		used = math.Ceil(prints / it.PerSheet)
	}
	return
}

func (iv *Inventory) status(it *InvItem) Rec {
	from, base := it.Since, 0.0
	start := 0
	counted := false
	for i, m := range iv.Moves {
		if toStr(m["item"]) == it.ID && toStr(m["type"]) == "count" {
			from, base, start, counted = toStr(m["ts"]), num(m["qty"]), i+1, true
		}
	}
	added, out, hasIn := 0.0, 0.0, false
	for i := start; i < len(iv.Moves); i++ {
		m := iv.Moves[i]
		if toStr(m["item"]) != it.ID {
			continue
		}
		switch toStr(m["type"]) {
		case "in":
			added += num(m["qty"])
			hasIn = true
		case "out":
			out += num(m["qty"])
		}
	}
	sold, bw, col := salesUse(it, from, "")
	rem := base + added - out - sold

	// how fast is it being used? (last 14 days)
	today := todayStr()
	winStart := time.Now().AddDate(0, 0, -13).Format("2006-01-02")
	days := 14.0
	if d, err := time.Parse("2006-01-02", from[:10]); err == nil {
		if n := time.Since(d).Hours()/24 + 1; n < days {
			days = math.Max(1, math.Floor(n))
		}
	}
	recent, _, _ := salesUse(it, from, winStart)
	for _, m := range iv.Moves {
		if toStr(m["item"]) == it.ID && toStr(m["type"]) == "out" && toStr(m["date"]) >= winStart && toStr(m["date"]) <= today && toStr(m["ts"]) > from {
			recent += num(m["qty"])
		}
	}
	perDay := recent / days
	var daysLeft any
	if perDay > 0 && rem > 0 && days >= 3 { // too early to predict before a few days of records
		daysLeft = math.Floor(rem / perDay)
	}

	shown := math.Max(0, rem)
	packs := math.Floor(shown / it.PackSize)
	state := "ok"
	switch {
	case !counted && !hasIn:
		state = "setup"
	case rem <= 0:
		state = "out"
	case shown/it.PackSize <= it.Reorder:
		state = "low"
	}
	return Rec{
		"id": it.ID, "name": it.Name, "packName": it.PackName, "unitName": it.UnitName, "packSize": it.PackSize,
		"reorder": it.Reorder, "perSheet": it.PerSheet, "auto": it.ID == "paper" || it.ID == "passport",
		"remaining": rem, "packs": packs, "loose": shown - packs*it.PackSize,
		"soldUse": sold, "bw": bw, "color": col, "manualOut": out, "added": added, "base": base, "from": from, "counted": counted,
		"state": state, "perDay": math.Round(perDay*10) / 10, "daysLeft": daysLeft, "needsCount": rem < 0,
	}
}

func inventoryView(adm bool) Rec {
	iv := db.Inventory
	items := []Rec{}
	alerts := 0
	for i := range iv.Items {
		s := iv.status(&iv.Items[i])
		if st := toStr(s["state"]); st == "low" || st == "out" {
			alerts++
		}
		items = append(items, s)
	}
	moves := []Rec{}
	today := todayStr()
	for i := len(iv.Moves) - 1; i >= 0 && len(moves) < 300; i-- {
		m := iv.Moves[i]
		if !adm && toStr(m["date"]) != today {
			continue
		}
		moves = append(moves, m)
	}
	return Rec{"items": items, "moves": moves, "alerts": alerts}
}

var (
	reInvMove = regexp.MustCompile(`^/api/inventory/moves/` + idRe + `$`)
	reInvItem = regexp.MustCompile(`^/api/inventory/items/` + idRe + `$`)
)

// inventoryRoutes returns true when it handled the request.
func inventoryRoutes(w http.ResponseWriter, r *http.Request, p, m string, b map[string]any) bool {
	if m == "POST" && p == "/api/inventory/move" {
		u, _ := need(r, false)
		it := db.Inventory.item(toStr(b["item"]))
		if it == nil {
			bad(400, "Unknown stock item")
		}
		typ := toStr(b["type"])
		if typ != "in" && typ != "out" && typ != "count" {
			bad(400, "Unknown stock action")
		}
		if typ != "out" && u.Role != "admin" {
			bad(403, "Admin only")
		}
		packs, loose := num(b["packs"]), num(b["loose"])
		if math.IsNaN(packs) || math.IsNaN(loose) || packs < 0 || loose < 0 {
			bad(400, "Enter a valid number")
		}
		packs, loose = math.Floor(packs), math.Floor(loose)
		qty := packs*it.PackSize + loose
		if qty > 1e7 || (typ != "count" && qty <= 0) {
			bad(400, fmt.Sprintf("Enter how many %s or %s", it.PackName+"s", it.UnitName))
		}
		note := str(b["note"], 120)
		if typ == "out" && note == "" {
			note = "Used"
		}
		ts := nowTS()
		db.Inventory.Moves = append(db.Inventory.Moves, Rec{"id": uid(), "item": it.ID, "type": typ, "qty": qty, "ts": ts, "date": ts[:10], "note": note, "by": u.Username})
		save()
		send(w, 200, Rec{"ok": true})
		return true
	}
	if m == "DELETE" {
		if mm := reInvMove.FindStringSubmatch(p); mm != nil {
			need(r, true)
			out := []Rec{}
			for _, x := range db.Inventory.Moves {
				if toStr(x["id"]) != mm[1] {
					out = append(out, x)
				}
			}
			db.Inventory.Moves = out
			save()
			send(w, 200, Rec{"ok": true})
			return true
		}
	}
	if m == "PUT" {
		if mm := reInvItem.FindStringSubmatch(p); mm != nil {
			need(r, true)
			it := db.Inventory.item(mm[1])
			if it == nil {
				bad(404, "Stock item not found")
			}
			if v := num(b["reorder"]); !math.IsNaN(v) && v >= 0 && v <= 10000 {
				it.Reorder = v
			}
			if v := math.Floor(num(b["packSize"])); !math.IsNaN(v) && v >= 1 && v <= 100000 {
				it.PackSize = v
			}
			if it.ID == "passport" {
				if v := num(b["perSheet"]); !math.IsNaN(v) && v >= 1 && v <= 1000 {
					it.PerSheet = math.Floor(v)
				}
			}
			save()
			send(w, 200, Rec{"ok": true})
			return true
		}
	}
	return false
}
