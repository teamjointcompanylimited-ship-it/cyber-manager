package main

// Minimal scrypt (RFC 7914) using only the Go standard library, so the
// password hashes are identical to Node's crypto.scryptSync (N=16384, r=8, p=1).

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/binary"
)

func blockMix(b, y []uint32, r int) {
	var x [16]uint32
	copy(x[:], b[(2*r-1)*16:])
	for i := 0; i < 2*r; i++ {
		for j := 0; j < 16; j++ {
			x[j] ^= b[i*16+j]
		}
		salsa8(&x)
		dst := (i/2)*16 + (i%2)*r*16
		copy(y[dst:dst+16], x[:])
	}
	copy(b, y)
}

func salsa8(b *[16]uint32) {
	x := *b
	rotl := func(a uint32, n uint) uint32 { return a<<n | a>>(32-n) }
	for i := 0; i < 8; i += 2 {
		x[4] ^= rotl(x[0]+x[12], 7)
		x[8] ^= rotl(x[4]+x[0], 9)
		x[12] ^= rotl(x[8]+x[4], 13)
		x[0] ^= rotl(x[12]+x[8], 18)
		x[9] ^= rotl(x[5]+x[1], 7)
		x[13] ^= rotl(x[9]+x[5], 9)
		x[1] ^= rotl(x[13]+x[9], 13)
		x[5] ^= rotl(x[1]+x[13], 18)
		x[14] ^= rotl(x[10]+x[6], 7)
		x[2] ^= rotl(x[14]+x[10], 9)
		x[6] ^= rotl(x[2]+x[14], 13)
		x[10] ^= rotl(x[6]+x[2], 18)
		x[3] ^= rotl(x[15]+x[11], 7)
		x[7] ^= rotl(x[3]+x[15], 9)
		x[11] ^= rotl(x[7]+x[3], 13)
		x[15] ^= rotl(x[11]+x[7], 18)
		x[1] ^= rotl(x[0]+x[3], 7)
		x[2] ^= rotl(x[1]+x[0], 9)
		x[3] ^= rotl(x[2]+x[1], 13)
		x[0] ^= rotl(x[3]+x[2], 18)
		x[6] ^= rotl(x[5]+x[4], 7)
		x[7] ^= rotl(x[6]+x[5], 9)
		x[4] ^= rotl(x[7]+x[6], 13)
		x[5] ^= rotl(x[4]+x[7], 18)
		x[11] ^= rotl(x[10]+x[9], 7)
		x[8] ^= rotl(x[11]+x[10], 9)
		x[9] ^= rotl(x[8]+x[11], 13)
		x[10] ^= rotl(x[9]+x[8], 18)
		x[12] ^= rotl(x[15]+x[14], 7)
		x[13] ^= rotl(x[12]+x[15], 9)
		x[14] ^= rotl(x[13]+x[12], 13)
		x[15] ^= rotl(x[14]+x[13], 18)
	}
	for i := range b {
		b[i] += x[i]
	}
}

func integerify(b []uint32, r int) uint64 {
	return uint64(b[(2*r-1)*16]) | uint64(b[(2*r-1)*16+1])<<32
}

func scryptKey(password, salt []byte, N, r, p, keyLen int) ([]byte, error) {
	pw := string(password)
	B, err := pbkdf2.Key(sha256.New, pw, salt, 1, p*128*r)
	if err != nil {
		return nil, err
	}
	w := 32 * r
	xy := make([]uint32, w)
	v := make([]uint32, w*N)
	x := make([]uint32, w)
	for i := 0; i < p; i++ {
		blk := B[i*128*r : (i+1)*128*r]
		for k := 0; k < w; k++ {
			x[k] = binary.LittleEndian.Uint32(blk[k*4:])
		}
		for n := 0; n < N; n++ {
			copy(v[n*w:], x)
			blockMix(x, xy, r)
		}
		for n := 0; n < N; n++ {
			j := int(integerify(x, r) & uint64(N-1))
			for k := 0; k < w; k++ {
				x[k] ^= v[j*w+k]
			}
			blockMix(x, xy, r)
		}
		for k := 0; k < w; k++ {
			binary.LittleEndian.PutUint32(blk[k*4:], x[k])
		}
	}
	return pbkdf2.Key(sha256.New, pw, B, 1, keyLen)
}
