package main

// Cyber Manager - shared server (Go port of the original Node.js server.js).
// Single self-contained program: the web page is embedded, no Node.js needed.

import (
	"bufio"
	"crypto/rand"
	"crypto/subtle"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

//go:embed public/index.html
var indexHTML []byte

const appVersion = "2.3.0"

var (
	port    = "3000"
	dataDir string
	dbFile  string
	bkDir   string
)

/* ---------- helpers ---------- */

func todayStr() string  { return time.Now().Format("2006-01-02") }
func pad2(n int) string { return fmt.Sprintf("%02d", n) }

func uid() string {
	b := make([]byte, 8)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func randHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// toStr mimics String(v ?? ”) for JSON values.
func toStr(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(x)
	default:
		bs, _ := json.Marshal(x)
		return string(bs)
	}
}

// str mimics str(v,max): String(v ?? ”).trim().slice(0,max)
func str(v any, max int) string {
	s := strings.TrimSpace(toStr(v))
	r := []rune(s)
	if len(r) > max {
		r = r[:max]
	}
	return string(r)
}

// num mimics unary plus (+v) on a JSON value; NaN when not numeric.
func num(v any) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case string:
		s := strings.TrimSpace(x)
		if s == "" {
			return 0
		}
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return math.NaN()
		}
		return f
	case bool:
		if x {
			return 1
		}
		return 0
	case nil:
		return 0
	}
	return math.NaN()
}

func jsRound(f float64) float64 { return math.Floor(f + 0.5) }

type httpErr struct {
	status int
	msg    string
}

func (e httpErr) Error() string  { return e.msg }
func bad(status int, msg string) { panic(httpErr{status, msg}) }

/* ---------- database ---------- */

// Prices is the old (v2.2.0 and earlier) price block. It is only read so that old data
// files can be converted into the services list; it is never written any more.
type Prices struct {
	BW       float64 `json:"bw"`
	Color    float64 `json:"color"`
	Scan     float64 `json:"scan"`
	Passport float64 `json:"passport"`
	Browse   float64 `json:"browse"`
}

// Service is something the shop sells (added in v2.3.0; the admin manages the list in Settings).
//
//	kind "print"  : black & white AND colour printing, two prices per page
//	kind "unit"   : one price per unit (page, print, minute, item ...)
//	kind "agreed" : no fixed price, the amount is typed in for each sale (KRA, NTSA, ...)
//
// A service that has sales recorded cannot be deleted - it is only stopped (Active=false),
// so the old sales still show and can still be corrected.
type Service struct {
	ID         string   `json:"id"`
	Name       string   `json:"name"`
	Icon       string   `json:"icon"`
	Kind       string   `json:"kind"`
	Unit       string   `json:"unit"`
	Price      float64  `json:"price"`      // per unit (for print: black & white price)
	ColorPrice float64  `json:"colorPrice"` // print only: colour price per page
	Hints      []string `json:"hints"`      // agreed only: suggestions for the job box
	Active     bool     `json:"active"`     // false = no longer offered on the sale screen
}

type Settings struct {
	Shop     string    `json:"shop"`
	Target   float64   `json:"target"`
	Google   string    `json:"google"`
	Services []Service `json:"services"`
	Prices   *Prices   `json:"prices,omitempty"` // old files only - converted into Services on load
}
type User struct {
	ID       string  `json:"id"`
	V        float64 `json:"v"`
	Name     string  `json:"name"`
	Username string  `json:"username"`
	Email    string  `json:"email"`
	Role     string  `json:"role"`
	Salt     string  `json:"salt"`
	Hash     *string `json:"hash"`
}
type PubUser struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Username string `json:"username"`
	Email    string `json:"email"`
	Role     string `json:"role"`
}
type Rec = map[string]any
type DB struct {
	Users        []User     `json:"users"`
	Transactions []Rec      `json:"transactions"`
	Expenses     []Rec      `json:"expenses"`
	Settings     Settings   `json:"settings"`
	Inventory    *Inventory `json:"inventory,omitempty"` // added in v2.2.0 - older data files simply do not have it
}

func defaults() *DB {
	return &DB{
		Users: []User{}, Transactions: []Rec{}, Expenses: []Rec{},
		Settings:  Settings{Shop: "My Cyber Cafe", Services: defaultServices(Prices{BW: 10, Color: 20, Scan: 20, Passport: 100, Browse: 2})},
		Inventory: newInventory(),
	}
}

// defaultServices is the list a new install starts with (the services the shop had before v2.3.0).
func defaultServices(p Prices) []Service {
	list := []Service{
		{ID: "print", Name: "Printing", Icon: "🖨️", Kind: "print", Unit: "page", Price: p.BW, ColorPrice: p.Color, Active: true},
		{ID: "scan", Name: "Document Scanning", Icon: "📄", Kind: "unit", Unit: "page", Price: p.Scan, Active: true},
		{ID: "passport", Name: "Passport Photo Printing", Icon: "🪪", Kind: "unit", Unit: "print", Price: p.Passport, Active: true},
		{ID: "browse", Name: "Browsing / Self-service", Icon: "💻", Kind: "unit", Unit: "minute", Price: p.Browse, Active: true},
		{ID: "kra", Name: "KRA Services", Icon: "🧾", Kind: "agreed", Hints: []string{"PIN registration", "Returns filing", "PIN retrieval", "Tax compliance certificate", "iTax account help"}, Active: true},
		{ID: "ntsa", Name: "NTSA Services", Icon: "🚗", Kind: "agreed", Hints: []string{"TIMS account", "Driving licence application", "Vehicle search", "Logbook transfer", "Driving licence renewal"}, Active: true},
		{ID: "afya", Name: "Afya Yangu / SHA", Icon: "🏥", Kind: "agreed", Hints: []string{"SHA registration", "Contribution payment", "Status check", "Update details"}, Active: true},
		{ID: "other", Name: "Other (negotiable)", Icon: "🧩", Kind: "agreed", Hints: []string{}, Active: true},
	}
	for i := range list {
		if list[i].Hints == nil {
			list[i].Hints = []string{}
		}
	}
	return list
}

// migrateSettings turns the old fixed prices (v2.2.0 and earlier) into the services list.
// A file that already has a services list is left alone.
func migrateSettings(s *Settings) {
	if s.Services == nil {
		p := Prices{BW: 10, Color: 20, Scan: 20, Passport: 100, Browse: 2}
		if s.Prices != nil {
			p = *s.Prices
		}
		s.Services = defaultServices(p)
	}
	s.Prices = nil
	for i := range s.Services {
		sv := &s.Services[i]
		if sv.Hints == nil {
			sv.Hints = []string{}
		}
		if sv.Kind == "print" && sv.Unit == "" {
			sv.Unit = "page"
		}
	}
}

// svc finds a service by id (nil when there is no such service).
func (s *Settings) svc(id string) *Service {
	for i := range s.Services {
		if s.Services[i].ID == id {
			return &s.Services[i]
		}
	}
	return nil
}

func normalize(d *DB) *DB {
	if d.Users == nil {
		d.Users = []User{}
	}
	if d.Transactions == nil {
		d.Transactions = []Rec{}
	}
	if d.Expenses == nil {
		d.Expenses = []Rec{}
	}
	if d.Inventory == nil {
		d.Inventory = newInventory()
	}
	d.Inventory.fix()
	migrateSettings(&d.Settings)
	return d
}

var (
	mu  sync.Mutex
	db  *DB
	rev = time.Now().UnixMilli()
)

func save() {
	rev++
	if db.Settings.Services == nil { // keep "[]" in the file, never "null"
		db.Settings.Services = []Service{}
	}
	func() { // one copy per day, taken before the first change of that day
		defer func() { recover() }()
		b := filepath.Join(bkDir, "cyber-data-"+todayStr()+".json")
		if _, err := os.Stat(dbFile); err == nil {
			if _, err := os.Stat(b); err != nil {
				if data, err := os.ReadFile(dbFile); err == nil {
					if err := os.WriteFile(b, data, 0o644); err != nil {
						fmt.Println("Backup copy failed:", err)
					}
				}
				ents, _ := os.ReadDir(bkDir)
				var old []string
				for _, e := range ents {
					if strings.HasPrefix(e.Name(), "cyber-data-") {
						old = append(old, e.Name())
					}
				}
				sort.Strings(old)
				if len(old) > 30 {
					for _, f := range old[:len(old)-30] {
						os.Remove(filepath.Join(bkDir, f))
					}
				}
			}
		}
	}()
	data, err := json.Marshal(db)
	if err != nil {
		panic(err)
	}
	tmp := dbFile + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		panic(err)
	}
	if err := os.Rename(tmp, dbFile); err != nil {
		panic(err)
	}
}

/* ---------- passwords & sessions ---------- */

func hashPw(pw, salt string) string {
	k, err := scryptKey([]byte(pw), []byte(salt), 16384, 8, 1, 64)
	if err != nil {
		panic(err)
	}
	return hex.EncodeToString(k)
}

func makeUser(name, username, email, role, pw string) User {
	salt := randHex(16)
	u := User{ID: uid(), V: 2, Name: name, Username: username, Email: email, Role: role, Salt: salt}
	if pw != "" {
		h := hashPw(pw, salt)
		u.Hash = &h
	}
	return u
}
func checkPw(u *User, pw string) bool {
	if u == nil || u.Hash == nil || *u.Hash == "" {
		return false
	}
	a, _ := hex.DecodeString(hashPw(pw, u.Salt))
	b, err := hex.DecodeString(*u.Hash)
	if err != nil || len(a) != len(b) {
		return false
	}
	return subtle.ConstantTimeCompare(a, b) == 1
}
func pub(u *User) PubUser {
	return PubUser{u.ID, u.Name, u.Username, u.Email, u.Role}
}

type session struct {
	uid string
	exp time.Time
}

var sessions = map[string]*session{}

const ttl = 12 * time.Hour

func newSession(userID string) string {
	t := randHex(24)
	sessions[t] = &session{userID, time.Now().Add(ttl)}
	return t
}
func findUser(id string) *User {
	for i := range db.Users {
		if db.Users[i].ID == id {
			return &db.Users[i]
		}
	}
	return nil
}
func auth(r *http.Request) (*User, string) {
	h := r.Header.Get("Authorization")
	t := ""
	if strings.HasPrefix(h, "Bearer ") {
		t = h[7:]
	}
	s := sessions[t]
	if s == nil {
		return nil, ""
	}
	if s.exp.Before(time.Now()) {
		delete(sessions, t)
		return nil, ""
	}
	u := findUser(s.uid)
	if u == nil {
		delete(sessions, t)
		return nil, ""
	}
	s.exp = time.Now().Add(ttl)
	return u, t
}
func need(r *http.Request, admin bool) (*User, string) {
	u, t := auth(r)
	if u == nil {
		bad(401, "Please log in")
	}
	if admin && u.Role != "admin" {
		bad(403, "Admin only")
	}
	return u, t
}
func killSessions(userID string) {
	for t, s := range sessions {
		if s.uid == userID {
			delete(sessions, t)
		}
	}
}

type fail struct {
	n int
	t time.Time
}

var fails = map[string]*fail{}

func limited(ip string) bool {
	f := fails[ip]
	return f != nil && f.n >= 10 && time.Since(f.t) < 10*time.Minute
}
func failed(ip string) {
	f := fails[ip]
	if f == nil || time.Since(f.t) >= 10*time.Minute {
		fails[ip] = &fail{1, time.Now()}
	} else {
		f.n++
	}
}

/* ---------- services (prices enforced here) ---------- */

// isAgreed: the sale has no fixed price (the amount is typed in).
func isAgreed(sv *Service, t Rec) bool {
	if sv != nil {
		return sv.Kind == "agreed"
	}
	return t["unit"] == nil // a service that no longer exists: judge by how the sale was saved
}

// saleName is the name stored on a sale (a snapshot, so later renames do not change old records).
func saleName(sv *Service, mode string) string {
	if sv.Kind == "print" {
		if mode == "color" {
			return sv.Name + " (Colour)"
		}
		return sv.Name + " (B&W)"
	}
	return sv.Name
}

// parseHints accepts a list or a comma-separated text.
func parseHints(v any) []string {
	var raw []string
	switch x := v.(type) {
	case []any:
		for _, h := range x {
			raw = append(raw, toStr(h))
		}
	case string:
		raw = strings.Split(x, ",")
	}
	out := []string{}
	for _, h := range raw {
		if h = str(h, 60); h != "" && len(out) < 12 {
			out = append(out, h)
		}
	}
	return out
}

// checkService validates the fields the admin sends and fills them into sv.
// Fields that are not in the request are left alone (used for partial updates).
func checkService(sv *Service, b map[string]any, adding bool) {
	if _, ok := b["name"]; ok || adding {
		name := str(b["name"], 60)
		if name == "" {
			bad(400, "Enter the name of the service")
		}
		sv.Name = name
	}
	if _, ok := b["icon"]; ok || adding {
		sv.Icon = str(b["icon"], 8)
		if sv.Icon == "" {
			sv.Icon = "🧩"
		}
	}
	if sv.Kind != "agreed" {
		if _, ok := b["unit"]; ok || adding {
			sv.Unit = strings.ToLower(str(b["unit"], 20))
			if sv.Unit == "" {
				sv.Unit = "item"
				if sv.Kind == "print" {
					sv.Unit = "page"
				}
			}
		}
		if _, ok := b["price"]; ok || adding {
			p := jsRound(num(b["price"]))
			if !(p >= 1 && p <= 1e6) {
				if sv.Kind == "print" {
					bad(400, "Enter the black & white price per page")
				}
				bad(400, "Enter a valid price")
			}
			sv.Price = p
		}
		if sv.Kind == "print" {
			if _, ok := b["colorPrice"]; ok || adding {
				c := jsRound(num(b["colorPrice"]))
				if !(c >= 1 && c <= 1e6) {
					bad(400, "Enter the colour price per page")
				}
				sv.ColorPrice = c
			}
		}
	} else {
		if _, ok := b["hints"]; ok || adding {
			sv.Hints = parseHints(b["hints"])
		}
	}
	if _, ok := b["active"]; ok {
		sv.Active = b["active"] == true
	}
}

/* ---------- credit helpers ---------- */

func findTx(id string) Rec {
	for _, x := range db.Transactions {
		if toStr(x["id"]) == id {
			return x
		}
	}
	return nil
}

// payments of a sale (works for freshly built []Rec and for data loaded from disk []any)
func payList(t Rec) []Rec {
	out := []Rec{}
	switch v := t["payments"].(type) {
	case []Rec:
		out = append(out, v...)
	case []any:
		for _, x := range v {
			if m, ok := x.(map[string]any); ok {
				out = append(out, m)
			}
		}
	}
	return out
}
func paidSum(t Rec) float64 {
	s := 0.0
	for _, p := range payList(t) {
		if n := num(p["amount"]); !math.IsNaN(n) {
			s += n
		}
	}
	return s
}
func payMethod(v any) string {
	if v == "M-Pesa" {
		return "M-Pesa"
	}
	return "Cash"
}
func newPayment(amount float64, method, date, by string) Rec {
	now := time.Now()
	return Rec{"id": uid(), "date": date, "ts": fmt.Sprintf("%sT%s:%s:00", date, pad2(now.Hour()), pad2(now.Minute())), "amount": amount, "method": method, "by": by}
}

/* ---------- HTTP ---------- */

func send(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	bs, _ := json.Marshal(body)
	w.Write(bs)
}

func readBody(r *http.Request) map[string]any {
	const limit = 60e6
	data, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
	if err != nil {
		bad(400, "Bad request")
	}
	if len(data) > limit {
		bad(413, "Too large")
	}
	b := map[string]any{}
	if len(strings.TrimSpace(string(data))) > 0 {
		var v any
		if err := json.Unmarshal(data, &v); err != nil {
			bad(400, "Bad request")
		}
		if m, ok := v.(map[string]any); ok {
			b = m
		}
	}
	return b
}

var (
	userRegex = regexp.MustCompile(`^[a-z0-9._-]{2,30}$`)
	dateRegex = regexp.MustCompile(`^\d{4}-\d{2}-\d{2}$`)
	idRe      = `([\w-]+)`
	reTx      = regexp.MustCompile(`^/api/transactions/` + idRe + `$`)
	reExp     = regexp.MustCompile(`^/api/expenses/` + idRe + `$`)
	reSvc     = regexp.MustCompile(`^/api/services/` + idRe + `$`)
	reTxPay   = regexp.MustCompile(`^/api/transactions/` + idRe + `/pay$`)
	reTxPayDe = regexp.MustCompile(`^/api/transactions/` + idRe + `/payments/` + idRe + `$`)
	reUsrPw   = regexp.MustCompile(`^/api/users/` + idRe + `/password$`)
	reUsr     = regexp.MustCompile(`^/api/users/` + idRe + `$`)
)

func clientIP(r *http.Request) string {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return h
}

func api(w http.ResponseWriter, r *http.Request, p string) {
	m, ip := r.Method, clientIP(r)
	b := map[string]any{}
	if m == "POST" || m == "PUT" {
		b = readBody(r)
	}
	var mm []string

	if m == "GET" && p == "/api/status" {
		send(w, 200, Rec{"needSetup": len(db.Users) == 0, "shop": db.Settings.Shop, "googleClientId": db.Settings.Google, "version": appVersion})
		return
	}

	if m == "POST" && p == "/api/setup" {
		if len(db.Users) > 0 {
			bad(403, "Already set up")
		}
		name, username, pw := str(b["name"], 80), strings.ToLower(str(b["username"], 30)), toStr(b["pw"])
		if name == "" {
			bad(400, "Enter your name")
		}
		if !userRegex.MatchString(username) {
			bad(400, "Username: 2-30 letters, numbers, dot, dash or underscore")
		}
		if len([]rune(pw)) < 6 {
			bad(400, "Password must be at least 6 characters")
		}
		if s := str(b["shop"], 80); s != "" {
			db.Settings.Shop = s
		}
		u := makeUser(name, username, strings.ToLower(str(b["email"], 120)), "admin", pw)
		db.Users = append(db.Users, u)
		save()
		send(w, 200, Rec{"token": newSession(u.ID), "user": pub(&u)})
		return
	}

	if m == "POST" && p == "/api/login" {
		if limited(ip) {
			bad(429, "Too many wrong attempts. Wait 10 minutes and try again.")
		}
		var u *User
		un := strings.ToLower(str(b["username"], 30))
		for i := range db.Users {
			if db.Users[i].Username == un {
				u = &db.Users[i]
				break
			}
		}
		if u == nil || !checkPw(u, toStr(b["password"])) {
			failed(ip)
			bad(401, "Wrong username or password")
		}
		delete(fails, ip)
		send(w, 200, Rec{"token": newSession(u.ID), "user": pub(u)})
		return
	}

	if m == "POST" && p == "/api/google" {
		cid := db.Settings.Google
		if cid == "" {
			bad(400, "Google sign-in is not set up")
		}
		var info map[string]any
		func() {
			defer func() {
				if recover() != nil {
					bad(502, "Could not verify with Google (is this computer online?)")
				}
			}()
			cl := &http.Client{Timeout: 15 * time.Second}
			resp, err := cl.Get("https://oauth2.googleapis.com/tokeninfo?id_token=" + url.QueryEscape(toStr(b["credential"])))
			if err != nil {
				panic(err)
			}
			defer resp.Body.Close()
			if err := json.NewDecoder(resp.Body).Decode(&info); err != nil || resp.StatusCode >= 300 {
				panic(errors.New("bad"))
			}
		}()
		if toStr(info["aud"]) != cid || toStr(info["email_verified"]) != "true" {
			bad(401, "Google sign-in failed")
		}
		email := strings.ToLower(toStr(info["email"]))
		var u *User
		for i := range db.Users {
			if db.Users[i].Email != "" && strings.ToLower(db.Users[i].Email) == email {
				u = &db.Users[i]
				break
			}
		}
		if u == nil {
			bad(403, fmt.Sprintf("This Google account (%s) is not registered. Ask the admin to add your email under Settings > Users.", toStr(info["email"])))
		}
		send(w, 200, Rec{"token": newSession(u.ID), "user": pub(u)})
		return
	}

	if m == "POST" && p == "/api/logout" {
		if u, t := auth(r); u != nil {
			delete(sessions, t)
		}
		send(w, 200, Rec{"ok": true})
		return
	}

	/* ----- everything below needs a login ----- */
	if m == "GET" && p == "/api/data" {
		u, _ := need(r, false)
		today := todayStr()
		tag := fmt.Sprintf("%d|%s|%s", rev, today, u.ID)
		if r.URL.Query().Get("tag") == tag {
			send(w, 200, Rec{"unchanged": true})
			return
		}
		adm := u.Role == "admin"
		users := []PubUser{}
		txs := []Rec{}
		exps := []Rec{}
		settings := Settings{Shop: db.Settings.Shop, Services: db.Settings.Services} // staff need the prices to make a sale
		if adm {
			settings = db.Settings
			txs = db.Transactions
			exps = db.Expenses
			for i := range db.Users {
				users = append(users, pub(&db.Users[i]))
			}
		} else {
			for _, t := range db.Transactions {
				if toStr(t["date"]) == today {
					txs = append(txs, t)
				}
			}
		}
		send(w, 200, Rec{"tag": tag, "now": time.Now().UnixMilli(), "me": pub(u), "settings": settings, "transactions": txs, "expenses": exps, "users": users, "inventory": inventoryView(adm)})
		return
	}

	if m == "POST" && p == "/api/transactions" {
		u, _ := need(r, false)
		sv := db.Settings.svc(toStr(b["service"]))
		if sv == nil || !sv.Active {
			bad(400, "That service is not on offer")
		}
		service := sv.ID
		qty := 1.0
		var unit any
		var total float64
		var mode any
		name := sv.Name
		var unitV float64
		if sv.Kind == "print" {
			md := "bw"
			unitV = sv.Price
			if b["mode"] == "color" {
				md = "color"
				unitV = sv.ColorPrice
			}
			mode = md
			name = saleName(sv, md)
			unit = unitV
		} else if sv.Kind == "unit" {
			unitV = sv.Price
			unit = unitV
		}
		if sv.Kind == "agreed" {
			total = jsRound(num(b["amount"]))
			if !(total > 0 && total <= 1e7) {
				bad(400, "Enter a valid amount")
			}
		} else {
			qty = math.Floor(num(b["qty"]))
			if !(qty >= 1 && qty <= 100000) {
				bad(400, "Enter a valid quantity")
			}
			total = qty * unitV
		}
		today := todayStr()
		date := today
		if u.Role == "admin" {
			if d := str(b["date"], 10); dateRegex.MatchString(d) && d <= today {
				date = d
			}
		}
		now := time.Now()
		mx := 0.0
		for _, x := range db.Transactions {
			if n, ok := x["no"].(float64); ok && n > mx {
				mx = n
			}
		}
		pay := "Cash"
		switch b["pay"] {
		case "M-Pesa":
			pay = "M-Pesa"
		case "Credit":
			pay = "Credit"
		}
		customer := str(b["customer"], 80)
		var payments []Rec
		if pay == "Credit" {
			if customer == "" {
				bad(400, "Enter the customer's name for a credit sale")
			}
			payments = []Rec{}
			if dep := jsRound(num(b["deposit"])); dep > 0 {
				if dep > total {
					bad(400, "The amount paid now is more than the total")
				}
				payments = append(payments, newPayment(dep, payMethod(b["depositMethod"]), date, u.Username))
			}
		}
		t := Rec{
			"id": uid(), "no": mx + 1, "date": date,
			"ts":      fmt.Sprintf("%sT%s:%s:%s", date, pad2(now.Hour()), pad2(now.Minute()), pad2(now.Second())),
			"service": service, "serviceName": name, "mode": mode, "qty": qty, "unit": unit, "total": total,
			"desc": str(b["desc"], 120), "customer": customer, "pay": pay, "note": str(b["note"], 200), "by": u.Username,
		}
		if payments != nil {
			t["payments"] = payments
		}
		db.Transactions = append(db.Transactions, t)
		save()
		send(w, 200, Rec{"transaction": t})
		return
	}

	if m == "DELETE" {
		if mm = reTx.FindStringSubmatch(p); mm != nil {
			need(r, true)
			out := []Rec{}
			for _, t := range db.Transactions {
				if toStr(t["id"]) != mm[1] {
					out = append(out, t)
				}
			}
			db.Transactions = out
			save()
			send(w, 200, Rec{"ok": true})
			return
		}
		if mm = reExp.FindStringSubmatch(p); mm != nil {
			need(r, true)
			out := []Rec{}
			for _, e := range db.Expenses {
				if toStr(e["id"]) != mm[1] {
					out = append(out, e)
				}
			}
			db.Expenses = out
			save()
			send(w, 200, Rec{"ok": true})
			return
		}
		if mm = reUsr.FindStringSubmatch(p); mm != nil {
			me, _ := need(r, true)
			if mm[1] == me.ID {
				bad(400, "You cannot delete your own account")
			}
			out := []User{}
			for _, x := range db.Users {
				if x.ID != mm[1] {
					out = append(out, x)
				}
			}
			db.Users = out
			killSessions(mm[1])
			save()
			send(w, 200, Rec{"ok": true})
			return
		}
	}

	/* ----- admin only: correct an old sale ----- */
	if m == "PUT" {
		if mm = reTx.FindStringSubmatch(p); mm != nil {
			need(r, true)
			t := findTx(mm[1])
			if t == nil {
				bad(404, "Sale not found")
			}
			sv := db.Settings.svc(toStr(t["service"])) // may be nil for an old, deleted service
			today := todayStr()
			date := toStr(t["date"])
			if d := str(b["date"], 10); d != "" {
				if !dateRegex.MatchString(d) || d > today {
					bad(400, "Enter a valid date (it cannot be in the future)")
				}
				date = d
			}
			agreed := isAgreed(sv, t)
			var total, qty, unitV float64
			qty = 1
			name := toStr(t["serviceName"])
			var mode any = t["mode"]
			if agreed {
				total = jsRound(num(b["amount"]))
				if !(total > 0 && total <= 1e7) {
					bad(400, "Enter a valid amount")
				}
			} else {
				qty = math.Floor(num(b["qty"]))
				if !(qty >= 1 && qty <= 100000) {
					bad(400, "Enter a valid quantity")
				}
				unitV = jsRound(num(b["unit"]))
				if !(unitV > 0 && unitV <= 1e6) {
					bad(400, "Enter a valid price per unit")
				}
				total = qty * unitV
				if sv != nil && sv.Kind == "print" {
					md := "bw"
					if b["mode"] == "color" {
						md = "color"
					}
					mode = md
					name = saleName(sv, md)
				}
			}
			pay := "Cash"
			switch b["pay"] {
			case "M-Pesa":
				pay = "M-Pesa"
			case "Credit":
				pay = "Credit"
			}
			customer := str(b["customer"], 80)
			if pay == "Credit" {
				if customer == "" {
					bad(400, "Enter the customer's name for a credit sale")
				}
				if pd := paidSum(t); total < pd {
					bad(400, fmt.Sprintf("The total cannot be less than the KSh %s already paid on this sale", strconv.FormatFloat(pd, 'f', -1, 64)))
				}
			}
			// all checks passed - apply
			if date != toStr(t["date"]) {
				old := toStr(t["ts"])
				tail := "T12:00:00"
				if len(old) > 10 {
					tail = old[10:]
				}
				t["date"], t["ts"] = date, date+tail
			}
			t["total"], t["qty"] = total, qty
			if !agreed {
				t["unit"] = unitV
			}
			t["serviceName"], t["mode"] = name, mode
			t["desc"], t["customer"], t["pay"], t["note"] = str(b["desc"], 120), customer, pay, str(b["note"], 200)
			if pay != "Credit" {
				delete(t, "payments")
			} else if _, ok := t["payments"]; !ok {
				t["payments"] = []Rec{}
			}
			save()
			send(w, 200, Rec{"transaction": t})
			return
		}
		if mm = reExp.FindStringSubmatch(p); mm != nil {
			need(r, true)
			var e Rec
			for _, x := range db.Expenses {
				if toStr(x["id"]) == mm[1] {
					e = x
					break
				}
			}
			if e == nil {
				bad(404, "Expense not found")
			}
			amount, date := jsRound(num(b["amount"])), str(b["date"], 10)
			if !(amount > 0 && amount <= 1e8) {
				bad(400, "Enter a valid amount")
			}
			if !dateRegex.MatchString(date) {
				bad(400, "Enter a valid date")
			}
			cat := str(b["cat"], 40)
			if cat == "" {
				cat = "Other"
			}
			e["date"], e["cat"], e["desc"], e["amount"] = date, cat, str(b["desc"], 200), amount
			save()
			send(w, 200, Rec{"ok": true})
			return
		}
	}

	/* ----- credit: record / undo a payment (admin only) ----- */
	if m == "POST" {
		if mm = reTxPay.FindStringSubmatch(p); mm != nil {
			u, _ := need(r, true)
			t := findTx(mm[1])
			if t == nil {
				bad(404, "Sale not found")
			}
			if toStr(t["pay"]) != "Credit" {
				bad(400, "This sale was not on credit")
			}
			balance := num(t["total"]) - paidSum(t)
			amount := jsRound(num(b["amount"]))
			if !(amount > 0) {
				bad(400, "Enter the amount paid")
			}
			if amount > balance {
				bad(400, fmt.Sprintf("That is more than the balance of KSh %s", strconv.FormatFloat(balance, 'f', -1, 64)))
			}
			date := todayStr()
			if d := str(b["date"], 10); dateRegex.MatchString(d) && d <= date {
				date = d
			}
			t["payments"] = append(payList(t), newPayment(amount, payMethod(b["method"]), date, u.Username))
			save()
			send(w, 200, Rec{"transaction": t})
			return
		}
	}
	if m == "DELETE" {
		if mm = reTxPayDe.FindStringSubmatch(p); mm != nil {
			need(r, true)
			t := findTx(mm[1])
			if t == nil {
				bad(404, "Sale not found")
			}
			out := []Rec{}
			for _, x := range payList(t) {
				if toStr(x["id"]) != mm[2] {
					out = append(out, x)
				}
			}
			t["payments"] = out
			save()
			send(w, 200, Rec{"transaction": t})
			return
		}
	}

	if inventoryRoutes(w, r, p, m, b) {
		return
	}

	if m == "POST" && p == "/api/expenses" {
		u, _ := need(r, true)
		amount, date := jsRound(num(b["amount"])), str(b["date"], 10)
		if !(amount > 0 && amount <= 1e8) {
			bad(400, "Enter a valid amount")
		}
		if !dateRegex.MatchString(date) {
			bad(400, "Enter a valid date")
		}
		cat := str(b["cat"], 40)
		if cat == "" {
			cat = "Other"
		}
		db.Expenses = append(db.Expenses, Rec{"id": uid(), "date": date, "cat": cat, "desc": str(b["desc"], 200), "amount": amount, "by": u.Username})
		save()
		send(w, 200, Rec{"ok": true})
		return
	}

	if m == "PUT" && p == "/api/settings" {
		need(r, true)
		s := &db.Settings
		if v := str(b["shop"], 80); v != "" {
			s.Shop = v
		}
		// prices are changed with the services list (/api/services), not here
		t := jsRound(num(b["target"]))
		if math.IsNaN(t) || t < 0 {
			t = 0
		}
		s.Target = t
		s.Google = str(b["google"], 200)
		save()
		send(w, 200, Rec{"ok": true})
		return
	}

	/* ----- admin only: the services the shop sells and their prices ----- */
	if m == "POST" && p == "/api/services" {
		need(r, true)
		sv := Service{ID: "s" + uid(), Kind: toStr(b["kind"]), Active: true, Hints: []string{}}
		if sv.Kind != "print" && sv.Kind != "unit" && sv.Kind != "agreed" {
			bad(400, "Choose what kind of service it is")
		}
		checkService(&sv, b, true)
		db.Settings.Services = append(db.Settings.Services, sv)
		save()
		send(w, 200, Rec{"service": sv})
		return
	}
	if m == "PUT" {
		if mm := reSvc.FindStringSubmatch(p); mm != nil {
			need(r, true)
			cur := db.Settings.svc(mm[1])
			if cur == nil {
				bad(404, "Service not found")
			}
			sv := *cur // change a copy, so a rejected change leaves the service as it was
			checkService(&sv, b, false)
			*cur = sv
			save()
			send(w, 200, Rec{"service": sv})
			return
		}
	}
	if m == "DELETE" {
		if mm := reSvc.FindStringSubmatch(p); mm != nil {
			need(r, true)
			sv := db.Settings.svc(mm[1])
			if sv == nil {
				bad(404, "Service not found")
			}
			if sv.ID == "print" || sv.ID == "passport" {
				bad(400, "Printing and passport photos are linked to the paper stock, so they can be stopped but not deleted")
			}
			for _, t := range db.Transactions {
				if toStr(t["service"]) == sv.ID {
					bad(400, "This service has sales recorded, so it cannot be deleted. Use Stop offering instead - the old sales will still show.")
				}
			}
			out := []Service{}
			for _, x := range db.Settings.Services {
				if x.ID != sv.ID {
					out = append(out, x)
				}
			}
			db.Settings.Services = out
			save()
			send(w, 200, Rec{"ok": true})
			return
		}
	}

	if m == "POST" && p == "/api/users" {
		need(r, true)
		name, username := str(b["name"], 80), strings.ToLower(str(b["username"], 30))
		email, pw := strings.ToLower(str(b["email"], 120)), toStr(b["pw"])
		if name == "" {
			bad(400, "Enter the full name")
		}
		if !userRegex.MatchString(username) {
			bad(400, "Username: 2-30 letters, numbers, dot, dash or underscore")
		}
		for _, x := range db.Users {
			if x.Username == username {
				bad(400, "That username already exists")
			}
		}
		if email != "" {
			for _, x := range db.Users {
				if x.Email == email {
					bad(400, "That email is already registered")
				}
			}
		}
		if pw == "" && email == "" {
			bad(400, "Give a password or a Google email")
		}
		if pw != "" && len([]rune(pw)) < 6 {
			bad(400, "Password must be at least 6 characters")
		}
		role := "staff"
		if b["role"] == "admin" {
			role = "admin"
		}
		db.Users = append(db.Users, makeUser(name, username, email, role, pw))
		save()
		send(w, 200, Rec{"ok": true})
		return
	}
	if m == "POST" {
		if mm = reUsrPw.FindStringSubmatch(p); mm != nil {
			need(r, true)
			u := findUser(mm[1])
			if u == nil {
				bad(404, "User not found")
			}
			pw := toStr(b["pw"])
			if len([]rune(pw)) < 6 {
				bad(400, "Password must be at least 6 characters")
			}
			u.Salt = randHex(16)
			h := hashPw(pw, u.Salt)
			u.Hash = &h
			u.V = 2
			save()
			killSessions(u.ID)
			send(w, 200, Rec{"ok": true})
			return
		}
	}

	if m == "GET" && p == "/api/backup" {
		need(r, true)
		send(w, 200, db)
		return
	}

	if m == "POST" && p == "/api/restore" {
		need(r, true)
		if _, ok := b["transactions"].([]any); !ok {
			bad(400, "Not a valid backup file")
		}
		raw, _ := json.Marshal(b)
		d := defaults()
		d.Inventory = nil         // so we can tell whether the backup file has stock records
		d.Settings.Services = nil // so an old backup (fixed prices) is converted, not mixed with the defaults
		if err := json.Unmarshal(raw, d); err != nil {
			bad(400, "Not a valid backup file")
		}
		hadInv := d.Inventory != nil
		normalize(d)
		if !hadInv && db.Inventory != nil { // backup made before v2.2.0: keep the stock records we have now
			d.Inventory = db.Inventory
		}
		full := len(d.Users) > 0
		hasAdmin := false
		for _, x := range d.Users {
			if x.V != 2 {
				full = false
			}
			if x.Role == "admin" {
				hasAdmin = true
			}
		}
		if full && hasAdmin {
			db = d
			save()
			send(w, 200, Rec{"message": "Full backup restored (including users)."})
			return
		}
		db.Transactions = d.Transactions
		db.Expenses = d.Expenses
		db.Settings.Services = d.Settings.Services
		db.Settings.Target = d.Settings.Target
		db.Settings.Shop = d.Settings.Shop
		if hadInv {
			db.Inventory = d.Inventory
		}
		save()
		send(w, 200, Rec{"message": "Imported sales, expenses and prices. Your current users were kept."})
		return
	}

	if m == "POST" && p == "/api/wipe" {
		need(r, true)
		if b["confirm"] != "DELETE" {
			bad(400, "Confirmation missing")
		}
		if data, err := os.ReadFile(dbFile); err == nil {
			os.WriteFile(filepath.Join(bkDir, fmt.Sprintf("before-wipe-%d.json", time.Now().UnixMilli())), data, 0o644)
		}
		db = defaults()
		sessions = map[string]*session{}
		save()
		send(w, 200, Rec{"ok": true})
		return
	}

	bad(404, "Not found")
}

func handler(w http.ResponseWriter, r *http.Request) {
	defer func() {
		if x := recover(); x != nil {
			if e, ok := x.(httpErr); ok {
				send(w, e.status, Rec{"error": e.msg})
			} else {
				fmt.Println("Server error:", x)
				send(w, 500, Rec{"error": "Server error"})
			}
		}
	}()
	mu.Lock()
	defer mu.Unlock()
	p := r.URL.Path
	if r.Method == "GET" && (p == "/" || p == "/index.html") {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Write(indexHTML)
		return
	}
	if p == "/favicon.ico" {
		w.WriteHeader(204)
		return
	}
	if strings.HasPrefix(p, "/api/") {
		api(w, r, p)
		return
	}
	send(w, 404, Rec{"error": "Not found"})
}

/* ---------- start-up ---------- */

func pause() {
	if runtime.GOOS == "windows" {
		fmt.Print("Press Enter to close this window...")
		bufio.NewReader(os.Stdin).ReadString('\n')
	}
}

func fatal(msg string) {
	fmt.Println(msg)
	pause()
	os.Exit(1)
}

func openBrowser(u string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", u).Start()
	case "darwin":
		exec.Command("open", u).Start()
	}
}

func defaultDataDir() string {
	if runtime.GOOS == "windows" {
		if pd := os.Getenv("ProgramData"); pd != "" {
			return filepath.Join(pd, "CyberManager", "data")
		}
	}
	exe, err := os.Executable()
	if err == nil {
		return filepath.Join(filepath.Dir(exe), "data")
	}
	return "data"
}

func main() {
	background := false
	for _, a := range os.Args[1:] {
		if a == "--background" {
			background = true
		}
	}
	if p := os.Getenv("PORT"); p != "" {
		port = p
	}
	dataDir = os.Getenv("DATA_DIR")
	if dataDir == "" {
		dataDir = defaultDataDir()
	}
	dbFile = filepath.Join(dataDir, "cyber-data.json")
	bkDir = filepath.Join(dataDir, "backups")
	if err := os.MkdirAll(bkDir, 0o755); err != nil {
		fatal("\nERROR: cannot create the data folder " + dataDir + "\n" + err.Error() + "\n")
	}

	db = defaults()
	if data, err := os.ReadFile(dbFile); err == nil {
		d := defaults()
		d.Inventory = nil         // so we can tell whether this data file already has the inventory section
		d.Settings.Services = nil // so we can tell whether this file already has the services list
		if err := json.Unmarshal(data, d); err != nil {
			fatal("\nERROR: the database file is damaged: " + dbFile + "\nRestore a copy from the data\\backups folder. The server will not start so nothing is overwritten.\n")
		}
		upgrading := d.Inventory == nil || d.Settings.Services == nil
		db = normalize(d)
		if upgrading { // first start after updating from an older version: store the new inventory section
			func() {
				defer func() {
					if r := recover(); r != nil {
						fmt.Println("Could not save inventory section:", r)
					}
				}()
				save() // save() first copies the old file into data/backups (once per day)
			}()
		}
	}

	ln, err := net.Listen("tcp", "0.0.0.0:"+port)
	if err != nil {
		fmt.Printf("\nPort %s is already in use - Cyber Manager is probably already running.\nOpening it in your browser...\n\n", port)
		if !background {
			openBrowser("http://localhost:" + port)
		}
		time.Sleep(2 * time.Second)
		os.Exit(1)
	}

	fmt.Println("\n  Cyber Manager " + appVersion + " is running.")
	fmt.Println("\n  On this computer open:   http://localhost:" + port)
	var ips []string
	if addrs, err := net.InterfaceAddrs(); err == nil {
		for _, a := range addrs {
			if ipn, ok := a.(*net.IPNet); ok && !ipn.IP.IsLoopback() && ipn.IP.To4() != nil && !ipn.IP.IsLinkLocalUnicast() {
				ips = append(ips, ipn.IP.String())
			}
		}
	}
	if len(ips) > 0 {
		fmt.Println("  On other computers open:")
		for _, ip := range ips {
			fmt.Println("      http://" + ip + ":" + port)
		}
	}
	fmt.Println("\n  Data is saved in: " + dataDir + "\n  Keep this window open while the cyber is working (you can minimise it).\n")

	if !background {
		go openBrowser("http://localhost:" + port)
	}
	srv := &http.Server{Handler: http.HandlerFunc(handler), ReadHeaderTimeout: 30 * time.Second}
	if err := srv.Serve(ln); err != nil {
		fatal(err.Error())
	}
}
