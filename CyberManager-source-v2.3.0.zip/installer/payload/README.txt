CYBER MANAGER
=============
One computer (the "server") keeps all the records. Every other computer in the
cyber opens the system in its browser, so everybody sees and adds to the same data.

START
-----
Double-click "Cyber Manager" on the desktop (or Start menu) on the SERVER computer.
A black window opens and your browser opens the system. Leave the black window open
(you may minimise it) while the cyber is working. Closing it stops the system.
First time only: create the admin account (shop name, your name, username, password).

OTHER COMPUTERS
---------------
The black window shows addresses such as  http://192.168.1.5:3000
On every other computer (same router / Wi-Fi / cable) open Chrome, type that address,
and press Ctrl+D to bookmark it.

ADD STAFF
---------
Log in as admin > Settings > Users > Add a user.
  Staff : can record sales and see TODAY's records only.
  Admin : sees everything (reports, profit/loss, expenses, settings, backups).

CREDIT SALES (pay later)
------------------------
New Sale > Payment > "Credit (pay later)". Enter the customer's name (required) and,
if they pay part now, the amount paid now. The admin sees everyone who still owes money
in the "Credit" tab, and records payments there (part or full). Unpaid credit is also
shown on the Dashboard and in Records.

SERVICES & PRICES (new in 2.3.0 - admin only)
---------------------------------------------
Admin > Settings > "Services & prices" sets up everything on the New Sale screen.
  Change a price : type the new price and press "Save" on that row. Printing has its own
                   black & white and colour prices. Only NEW sales use the new price;
                   sales already recorded keep the price they were sold at.
  Add a service  : fill in "Add a new service" at the bottom and choose its type:
                     Charged per unit  one price per page / print / minute / item
                                       (e.g. Lamination, KSh 30 per sheet)
                     Black & white AND colour printing  two prices per page
                     Agreed price      staff type the amount for each sale (e.g. KRA, NTSA)
  No longer offer: press "Stop offering". The service leaves the New Sale screen, but its
                   old sales stay in Records and can still be corrected. "Offer again" brings it back.
  Delete         : only for a service with no sales yet. Printing and passport photo printing
                   are linked to the paper stock, so they can be stopped but not deleted.
Staff can make sales at the prices shown, but cannot change services or prices.
Updating from an earlier version keeps your current prices: they are moved into the new list
automatically, and all old sales keep their names and prices.

CORRECTING OLD RECORDS (admin only)
-----------------------------------
Admin > Records > choose the day / week / month (Yesterday, This week, Last week,
Last month or any dates) > press "Edit" on a sale to change the date, quantity, price,
payment type, customer or note. Expenses can be edited too. Staff cannot edit anything.

INVENTORY (new in 2.2.0)
------------------------
Everybody: Inventory tab. It tracks four items:
  Printing paper       1 ream  = 500 sheets
  Envelopes            1 bunch = 50 envelopes
  Passport photo paper 1 packet = 100 sheets
  Sticker paper        1 packet = 100 sheets
FIRST TIME (admin): on each card press "Count stock" and enter what you have now.
After that:
  - Printing paper goes down by itself: every page printed (B&W or colour) = 1 sheet.
    Correcting or deleting a sale in Records corrects the stock automatically.
  - Passport photo paper goes down by itself from passport photo sales
    (1 print = 1 sheet; if several photos fit on one sheet, set it under "Alert level").
  - Envelopes and sticker paper: press "Record used" when you use some.
  - When you buy more: admin presses "Add stock" (e.g. 2 reams).
  - Jam / spoiled pages: "Spoiled / other use".
A card turns orange "Restock needed" when the stock falls to the alert level
(default 2 reams, 2 bunches, 1 packet - change it with "Alert level"), and red when finished.
A warning also shows on the Dashboard. Admin sees the full stock history; staff see today's.

RECEIPTS (new in 2.2.0)
-----------------------
Records > "Receipt" (or the link after saving a sale) opens the receipt.
Press "Print" to print it, or "Download PDF" to save a soft copy (80 mm receipt size)
that can be sent by WhatsApp or email.

UPDATING TO A NEW VERSION
-------------------------
Just run the new Setup on the SERVER computer. It updates the program and keeps ALL
records, users and prices. A safety copy is saved first in ...\data\backups
(before-update-to-<version>-<time>.json). No need to uninstall the old version.

DATA & BACKUPS
--------------
All records:  C:\ProgramData\CyberManager\data\cyber-data.json
A copy is saved automatically every day in  ...\data\backups  (last 30 days kept).
Also use Settings > Download backup now and then and keep a copy on a flash disk.
To move to a new server computer: install there, then Settings > Restore backup.
Uninstalling does NOT delete your records unless you choose so.

If other computers cannot open it
---------------------------------
 - Make sure all computers are on the same router/network.
 - Make sure the black window is still open on the server.
 - The installer already allows Cyber Manager through the Windows firewall for your local network.
