module cybermanager-setup

go 1.24
