package main

// Cyber Manager installer / uninstaller (single exe, standard library only).

import (
	"bufio"
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
)

//go:embed payload/CyberManager.exe
var appExe []byte

//go:embed payload/README.txt
var readme []byte

const (
	appName   = "Cyber Manager"
	version   = "2.3.0"
	exeName   = "CyberManager.exe"
	uninstReg = `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\CyberManager`
	runReg    = `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run`
	fwRule    = "Cyber Manager"
)

var (
	silent bool
	in     = bufio.NewReader(os.Stdin)
)

func hidden(name string, args ...string) *exec.Cmd {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return c
}

func run(name string, args ...string) error {
	out, err := hidden(name, args...).CombinedOutput()
	if err != nil {
		return fmt.Errorf("%v: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}

func say(f string, a ...any) { fmt.Printf(f+"\n", a...) }

func ask(q string, def bool) bool {
	if silent {
		return def
	}
	d := "Y/n"
	if !def {
		d = "y/N"
	}
	fmt.Printf("%s [%s]: ", q, d)
	s, _ := in.ReadString('\n')
	s = strings.ToLower(strings.TrimSpace(s))
	if s == "" {
		return def
	}
	return s[0] == 'y'
}

func pause() {
	if silent {
		return
	}
	fmt.Print("\nPress Enter to close this window...")
	in.ReadString('\n')
}

func die(f string, a ...any) {
	say("\nERROR: "+f, a...)
	pause()
	os.Exit(1)
}

func isAdmin() bool {
	f, err := os.Open(`\\.\PHYSICALDRIVE0`) // only succeeds with administrator rights
	if err != nil {
		return false
	}
	f.Close()
	return true
}

func relaunchElevated() {
	self, _ := os.Executable()
	var quoted []string
	for _, a := range os.Args[1:] {
		quoted = append(quoted, "'"+strings.ReplaceAll(a, "'", "''")+"'")
	}
	ps := fmt.Sprintf("Start-Process -FilePath '%s' -Verb RunAs", strings.ReplaceAll(self, "'", "''"))
	if len(quoted) > 0 {
		ps += " -ArgumentList " + strings.Join(quoted, ",")
	}
	if err := hidden("powershell", "-NoProfile", "-Command", ps).Run(); err != nil {
		die("Administrator permission is needed to install. Right-click the setup file and choose \"Run as administrator\".")
	}
}

func progFiles() string {
	if p := os.Getenv("ProgramFiles"); p != "" {
		return p
	}
	return `C:\Program Files`
}
func progData() string {
	if p := os.Getenv("ProgramData"); p != "" {
		return p
	}
	return `C:\ProgramData`
}

func psScript(body string) error {
	f, err := os.CreateTemp("", "cm-*.ps1")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	f.WriteString(body)
	f.Close()
	return run("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", f.Name())
}

func q(s string) string { return strings.ReplaceAll(s, "'", "''") }

func makeShortcuts(dir string) error {
	exe := filepath.Join(dir, exeName)
	return psScript(fmt.Sprintf(`$ErrorActionPreference='Stop'
$sh = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath('CommonDesktopDirectory')
$prog = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) '%[3]s'
New-Item -ItemType Directory -Force -Path $prog | Out-Null
foreach ($p in @((Join-Path $desk '%[3]s.lnk'), (Join-Path $prog '%[3]s.lnk'))) {
  $s = $sh.CreateShortcut($p)
  $s.TargetPath = '%[1]s'
  $s.WorkingDirectory = '%[2]s'
  $s.IconLocation = '%[1]s,0'
  $s.Description = 'Start the Cyber Manager server and open it in the browser'
  $s.Save()
}
$u = $sh.CreateShortcut((Join-Path $prog 'Uninstall %[3]s.lnk'))
$u.TargetPath = '%[4]s'
$u.Arguments = '--uninstall'
$u.WorkingDirectory = '%[2]s'
$u.Save()
`, q(exe), q(dir), appName, q(filepath.Join(dir, "uninstall.exe"))))
}

func removeShortcuts() {
	psScript(fmt.Sprintf(`$desk = [Environment]::GetFolderPath('CommonDesktopDirectory')
$prog = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) '%[1]s'
Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $desk '%[1]s.lnk')
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $prog
`, appName))
}

// installedVersion returns the version of an existing Cyber Manager install ("" if none).
func installedVersion(dir string) string {
	out, err := hidden("reg", "query", uninstReg, "/v", "DisplayVersion").CombinedOutput()
	if err == nil {
		for _, ln := range strings.Split(string(out), "\n") {
			if f := strings.Fields(ln); len(f) >= 3 && f[0] == "DisplayVersion" {
				return f[len(f)-1]
			}
		}
	}
	if _, err := os.Stat(filepath.Join(dir, exeName)); err == nil {
		return "older"
	}
	return ""
}

func autostartOn() bool {
	return hidden("reg", "query", runReg, "/v", "CyberManager").Run() == nil
}

func copyFile(src, dst string) error {
	b, err := os.ReadFile(src)
	if err != nil {
		return err
	}
	return os.WriteFile(dst, b, 0o644)
}

// writeRetry keeps trying for a few seconds (the old program may still be closing).
func writeRetry(path string, b []byte, mode os.FileMode) error {
	var err error
	for i := 0; i < 10; i++ {
		if err = os.WriteFile(path, b, mode); err == nil {
			return nil
		}
		time.Sleep(time.Second)
	}
	return err
}

func install() {
	dir := filepath.Join(progFiles(), appName)
	data := filepath.Join(progData(), "CyberManager")
	old := installedVersion(dir)
	update := old != ""
	dbPath := filepath.Join(data, "data", "cyber-data.json")
	_, dbErr := os.Stat(dbPath)
	haveData := dbErr == nil

	say("==============================================")
	if update {
		say("  %s - Update to version %s", appName, version)
	} else {
		say("  %s %s - Setup", appName, version)
	}
	say("==============================================\n")
	say("Install folder : %s", dir)
	say("Records folder : %s\\data\n", data)
	if update {
		if old == "older" {
			say("An earlier version of Cyber Manager is already installed.")
		} else {
			say("Version %s is already installed - it will be updated to %s.", old, version)
		}
		if haveData {
			say("ALL your existing records (sales, expenses, users, prices) are kept.")
		}
		say("")
	}

	qs := "Install Cyber Manager now?"
	if update {
		qs = "Update Cyber Manager now? (your records are kept)"
	}
	if !ask(qs, true) {
		say("Cancelled.")
		pause()
		return
	}
	var autostart bool
	if update {
		autostart = autostartOn() // keep whatever the shop had chosen before
	} else {
		autostart = ask("Start Cyber Manager automatically when this computer is switched on?", false)
	}

	say("\n[1/6] Stopping any running copy...")
	hidden("taskkill", "/IM", exeName, "/F").Run()
	time.Sleep(2 * time.Second)

	say("[2/6] Saving a safety copy of your records...")
	if haveData {
		bk := filepath.Join(data, "data", "backups")
		os.MkdirAll(bk, 0o755)
		name := fmt.Sprintf("before-update-to-%s-%s.json", version, time.Now().Format("20060102-150405"))
		if err := copyFile(dbPath, filepath.Join(bk, name)); err != nil {
			die("could not back up your records, so the update was stopped to keep them safe: %v", err)
		}
		say("   saved: %s", filepath.Join(bk, name))
	} else {
		say("   (no records yet - nothing to copy)")
	}

	say("[3/6] Copying files...")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		die("cannot create %s: %v", dir, err)
	}
	if err := writeRetry(filepath.Join(dir, exeName), appExe, 0o755); err != nil {
		die("cannot write program file (is Cyber Manager still open? close it and try again): %v", err)
	}
	os.WriteFile(filepath.Join(dir, "README.txt"), readme, 0o644)
	self, _ := os.Executable()
	if b, err := os.ReadFile(self); err == nil {
		writeRetry(filepath.Join(dir, "uninstall.exe"), b, 0o755)
	}
	// NOTE: the records folder is only created if missing - existing records are never touched.
	os.MkdirAll(filepath.Join(data, "data", "backups"), 0o755)
	// let every Windows user on this PC write the records (S-1-5-32-545 = Users)
	if err := run("icacls", data, "/grant", "*S-1-5-32-545:(OI)(CI)M", "/T", "/C", "/Q"); err != nil {
		say("   warning: could not set folder permissions (%v)", err)
	}

	say("[4/6] Creating shortcuts...")
	if err := makeShortcuts(dir); err != nil {
		say("   warning: could not create shortcuts (%v)", err)
	}

	say("[5/6] Allowing other computers in the shop to connect (Windows Firewall)...")
	run("netsh", "advfirewall", "firewall", "delete", "rule", "name="+fwRule)
	if err := run("netsh", "advfirewall", "firewall", "add", "rule", "name="+fwRule, "dir=in", "action=allow",
		"program="+filepath.Join(dir, exeName), "enable=yes", "profile=any", "remoteip=localsubnet"); err != nil {
		say("   warning: could not add firewall rule (%v)", err)
	}

	say("[6/6] Registering with Windows (Apps & features)...")
	installRegister(dir, autostart)

	if update {
		say("\nDone! %s was updated to version %s. Your records are untouched.", appName, version)
	} else {
		say("\nDone! %s is installed.", appName)
	}
	say("Use the \"%s\" icon on the desktop to start it.", appName)
	if ask("\nStart Cyber Manager now?", true) {
		c := exec.Command("cmd", "/c", "start", "", filepath.Join(dir, exeName))
		c.Dir = dir
		c.Start()
		time.Sleep(time.Second)
	}
	pause()
}

func installRegister(dir string, autostart bool) {
	un := fmt.Sprintf(`"%s" --uninstall`, filepath.Join(dir, "uninstall.exe"))
	for _, kv := range [][3]string{
		{"DisplayName", "REG_SZ", appName}, {"DisplayVersion", "REG_SZ", version}, {"Publisher", "REG_SZ", "Cyber Manager"},
		{"InstallLocation", "REG_SZ", dir}, {"DisplayIcon", "REG_SZ", filepath.Join(dir, exeName)},
		{"UninstallString", "REG_SZ", un}, {"NoModify", "REG_DWORD", "1"}, {"NoRepair", "REG_DWORD", "1"},
	} {
		run("reg", "add", uninstReg, "/v", kv[0], "/t", kv[1], "/d", kv[2], "/f")
	}
	if autostart {
		run("reg", "add", runReg, "/v", "CyberManager", "/t", "REG_SZ", "/d", fmt.Sprintf(`"%s" --background`, filepath.Join(dir, exeName)), "/f")
	} else {
		run("reg", "delete", runReg, "/v", "CyberManager", "/f")
	}
}

func uninstall() {
	say("==============================================")
	say("  %s - Uninstall", appName)
	say("==============================================\n")
	dir := filepath.Join(progFiles(), appName)
	if self, err := os.Executable(); err == nil {
		dir = filepath.Dir(self)
	}
	data := filepath.Join(progData(), "CyberManager")
	if !ask("Remove Cyber Manager from this computer?", true) {
		say("Cancelled.")
		pause()
		return
	}
	delData := ask("ALSO delete all your sales records and backups? (choose No to keep them)", false)
	if delData && !silent {
		delData = ask("Are you SURE? This cannot be undone", false)
	}
	hidden("taskkill", "/IM", exeName, "/F").Run()
	time.Sleep(time.Second)
	removeShortcuts()
	run("netsh", "advfirewall", "firewall", "delete", "rule", "name="+fwRule)
	run("reg", "delete", runReg, "/v", "CyberManager", "/f")
	run("reg", "delete", uninstReg, "/f")
	if delData {
		os.RemoveAll(data)
	}
	os.Remove(filepath.Join(dir, exeName))
	os.Remove(filepath.Join(dir, "README.txt"))
	say("\n%s has been removed.", appName)
	if !delData {
		say("Your records were kept in: %s", data)
	}
	pause()
	// this program is "uninstall.exe" itself, so delete its folder after it exits
	hidden("cmd", "/c", fmt.Sprintf(`ping -n 3 127.0.0.1 >nul & rmdir /s /q "%s"`, dir)).Start()
}

func main() {
	uninst := false
	for _, a := range os.Args[1:] {
		switch strings.ToLower(a) {
		case "/s", "--silent", "-s":
			silent = true
		case "--uninstall", "/uninstall":
			uninst = true
		}
	}
	if runtime.GOOS != "windows" {
		fmt.Println("This installer only runs on Windows.")
		os.Exit(1)
	}
	if !isAdmin() {
		relaunchElevated()
		return
	}
	if uninst {
		uninstall()
	} else {
		install()
	}
}
